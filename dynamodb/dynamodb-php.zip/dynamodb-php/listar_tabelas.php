<?php

//Carrega SDK da AWS
require 'aws/aws-autoloader.php';

//Define Timezone
date_default_timezone_set('UTC');

//Define região da AWS onde estão as Tabelas do DynamoDB
$sdk = new Aws\Sdk([
    'region'   => 'us-east-1',
    'version'  => 'latest'
]);

//Instancia Objeto do DynamoDB
$dynamodb = $sdk->createDynamoDb();

//Executa operação que lista todas as tabelas
$result = $dynamodb->listTables([
]);

// Faz um echo de cada tabela
foreach ($result['TableNames'] as $value) {
   echo 'Tabela => '. $value .'<br>' ;
}

//echo $result['TableNames'][0];

?>