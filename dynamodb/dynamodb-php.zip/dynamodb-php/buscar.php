<?php

//Carrega SDK da AWS
require 'aws/aws-autoloader.php';

//Define Timezone
date_default_timezone_set('UTC');

//Faz uso de Namespaces para tratamento de Exception
use Aws\DynamoDb\Exception\DynamoDbException;

//Define região da AWS onde estão as Tabelas do DynamoDB
$sdk = new Aws\Sdk([
    'region'   => 'us-east-1',
    'version'  => 'latest'
]);

//Instancia Objeto do DynamoDB
$dynamodb = $sdk->createDynamoDb();

// Tabela a ser scaneada
$tableName = 'produtos';

//Parametros recuperados na Query String - buscar.php?produto=Meu Produto&vendedor=Joao
$produto  = $_GET['produto'];
$vendedor = $_GET['vendedor'];

// formata Primary key com valores recebidos
$params = [
    'TableName' => $tableName,
    'Limit' => 5,
    'ExclusiveStartKey' => [
    	'produto' => [
    		'S' => $produto,
    	],
    	'vendedor' => [
    		'S' => $vendedor,
    	]
    ]
 ];

 //Executa Scan
try {
    $result = $dynamodb->scan($params);
    echo $result;

} catch (DynamoDbException $e) {
    echo "Erro ao Rodar Scan:\n";
    echo $e->getMessage() . "\n";
}

?>