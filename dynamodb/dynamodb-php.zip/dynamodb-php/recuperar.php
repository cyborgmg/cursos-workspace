<?php

//Carrega SDK da AWS
require 'aws/aws-autoloader.php';

//Define Timezone
date_default_timezone_set('UTC');

//Faz uso de Namespaces para tratamento de Exception
use Aws\DynamoDb\Exception\DynamoDbException;
//Faz uso de Namespaces para manipulação de Json
use Aws\DynamoDb\Marshaler;

//Define região da AWS onde estão as Tabelas do DynamoDB
$sdk = new Aws\Sdk([
    'region'   => 'us-east-1',
    'version'  => 'latest'
]);

//Instancia Objeto do DynamoDB
$dynamodb = $sdk->createDynamoDb();
//Instancia Objeto para manipulação de Json
$marshaler = new Marshaler();

//Tabela onde será recuperado o item
$tableName = 'clientes';

//Parametros recuperados na Query String - recuperar.php?email=joao@joao.com&nome=Joao
$nome  = $_GET['nome'];
$email = $_GET['email'];

//Formata Primary key com valores recebidos
$key = $marshaler->marshalJson('
    {
        "email":  " ' . $email . '",
        "nome":   " ' . $nome  . '"      
    }
');

 //Monta Params para fazer a recuperação
$params = [
    'TableName' => $tableName,
    'Key' => $key,
    'AttributesToGet' => [ 'email','nome','idade'],
    'ConsistentRead' => false,
    'ReturnConsumedCapacity'=> 'TOTAL'
];

//Executa a Recuperação
try {
    $result = $dynamodb->getItem($params);
    echo $result;

} catch (DynamoDbException $e) {
    echo "Unable to add item:\n";
    echo $e->getMessage() . "\n";
}


?>