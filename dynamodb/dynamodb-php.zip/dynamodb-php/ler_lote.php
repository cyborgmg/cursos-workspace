<?php

//Carrega SDK da AWS
require 'aws/aws-autoloader.php';

//Define Timezone
date_default_timezone_set('UTC');

//Faz uso de Namespaces para tratamento de Exception
use Aws\DynamoDb\Exception\DynamoDbException;
//Faz uso de Namespaces para manipulação de Json
use Aws\DynamoDb\Marshaler;

//Define região da AWS onde estão as Tabelas do DynamoDB
$sdk = new Aws\Sdk([
    'region'   => 'us-east-1',
    'version'  => 'latest'
]);

//Instancia Objeto do DynamoDB
$dynamodb = $sdk->createDynamoDb();
//Instancia Objeto para manipulação de Json
$marshaler = new Marshaler();

//Parametros recuperados na Query String - ler_lote.php?email=joao@joao.com&nome=Joao
$nome  = $_GET['nome'];
$email = $_GET['email'];

 //Monta Params para fazer a leitura em lote
$params = array(
    'RequestItems' => array(
        'clientes' => array(
            'Keys' => array(
                array(
                    'email' => array(
                        'S' =>  $email 
                    ),
                    'nome' => array(
                        'S' =>  $nome 
                    )
                )
            )
        ),
        'clientes_loja' => array(
            'Keys' => array(
                array(
                    'email' => array(
                        'S' =>  $email 
                    ),
                    'nome' => array(
                        'S' =>  $nome 
                    )
                )
            )
        )
    )
);

//Executa a leitura em lote
try {
    $result = $dynamodb->batchGetItem($params);
    echo $result;

} catch (DynamoDbException $e) {
    echo "Unable to add item:\n";
    echo $e->getMessage() . "\n";
}


?>


