<?php

//Carrega SDK da AWS
require 'aws/aws-autoloader.php';

//Define Timezone
date_default_timezone_set('UTC');

//Faz uso de Namespaces para tratamento de Exception
use Aws\DynamoDb\Exception\DynamoDbException;
//Faz uso de Namespaces para manipulação de Json
use Aws\DynamoDb\Marshaler;

//Define região da AWS onde estão as Tabelas do DynamoDB
$sdk = new Aws\Sdk([
    'region'   => 'us-east-1',
    'version'  => 'latest'
]);

//Instancia Objeto do DynamoDB
$dynamodb = $sdk->createDynamoDb();
//Instancia Objeto para manipulação de Json
$marshaler = new Marshaler();

//Tabela onde serão inseridos os itens
$tableName = 'clientes';

//Parametros recuperados na Query String - inserir.php?email=joao@joao.com&nome=Joao
$nome  = $_GET['nome'];
$email = $_GET['email'];

// formata Primary key com valores recebidos
$item = $marshaler->marshalJson('
    {
        "email":  " ' . $email . '",
        "nome":   " ' . $nome  . '" 
        
    }
');

 //Monta Params para fazer a inclusão
$params = [
    'TableName' => $tableName,
    'Item' => $item
];

//Executa a inclusão
try {
    $result = $dynamodb->putItem($params);
    echo "Item Adicionado";

} catch (DynamoDbException $e) {
    echo "Unable to add item:\n";
    echo $e->getMessage() . "\n";
}



?>