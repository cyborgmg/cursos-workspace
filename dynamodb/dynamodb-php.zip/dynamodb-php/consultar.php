<?php

//Carrega SDK da AWS
require 'aws/aws-autoloader.php';

//Define Timezone
date_default_timezone_set('UTC');

//Faz uso de Namespaces para tratamento de Exception
use Aws\DynamoDb\Exception\DynamoDbException;

//Define região da AWS onde estão as Tabelas do DynamoDB
$sdk = new Aws\Sdk([
    'region'   => 'us-east-1',
    'version'  => 'latest'
]);

//Instancia Objeto do DynamoDB
$dynamodb = $sdk->createDynamoDb();

//Tabela a ser consultada
$tableName = 'produtos';

//Parametros recuperados na Query String - consultar.php?produto=Meu Produto&categoria=Sapatos
$produto   = $_GET['produto'];
$categoria = $_GET['categoria'];

// formata Primary key com valores recebidos
$params = [
    'TableName' => $tableName,
    'IndexName' => 'produto-categoria-index',
    'KeyConditionExpression' =>'produto = :p_produto and categoria = :p_categoria',
    'ExpressionAttributeValues' => [
        ':p_produto' => [
            'S' => $produto,
        ],
        ':p_categoria' => [
            'S' => $categoria,
        ]
    ],
 ];

//Monta Params para fazer a busca
try {
    $result = $dynamodb->query($params);
    echo $result;

} catch (DynamoDbException $e) {
    echo "Erro ao Rodar a Query:\n";
    echo $e->getMessage() . "\n";
}

?>