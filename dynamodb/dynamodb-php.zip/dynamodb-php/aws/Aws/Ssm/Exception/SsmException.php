<?php
namespace Aws\Ssm\Exception;

use Aws\Exception\AwsException;

/**
 * Amazon EC2 Simple Systems Manager exception.
 */
class SsmException extends AwsException {}
